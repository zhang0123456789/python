#!/usr/bin/env python 
# -*- coding:utf-8 -*-
# @Time :2018/11/27 19:39
import math
class Tool:
    def add(self,a,b):
        print('a加b={}'.format(a+b))
        return a+b
    def sub(self,a,b):
        print("a减b={}".format(a-b))
        return  a-b
    def multi(self,a,b):
        print('a乘b={}'.format(a*b))
        return  a *b
    def division(self,a,b):
        print('a除b={}'.format(a/b))
        return a /b
    def square_integrable_function(self,a,b):
        c=pow(a,2)
        d=pow(b,2)
        print('a^2乘b^2={}'.format(c*d))
        return c*d










